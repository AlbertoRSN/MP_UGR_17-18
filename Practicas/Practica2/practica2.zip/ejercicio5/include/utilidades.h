//Archivo utilidades.h

#ifndef UTILIDADES_H
#define UTILIDADES_H


int tamanoCadena(char cadena[]);
bool insertarCadena(char inicial[], char aInsertar[], int pos, char resultado[]);

#endif