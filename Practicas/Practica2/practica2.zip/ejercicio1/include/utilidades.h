//Archivo utilidades.h

#ifndef UTILIDADES_H
#define UTILIDADES_H

int mezclar(double v1[], int length1, double v2[], int length2, double resultado[]);
void imprimirArray(double arg[], int length);

#endif