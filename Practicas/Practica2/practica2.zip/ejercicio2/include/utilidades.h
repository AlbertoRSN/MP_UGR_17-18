//Archivo utilidades.h

#ifndef UTILIDADES_H
#define UTILIDADES_H


int combinaSuma(Valor array1[], int tam1, Valor array2[], int tam2, Valor &resultado[]);

//Metodo auxiliar para comprobar si un array esta o no.
bool estaContenido(Valor array1[], int tam1, Valor array2[], int tam2);


#endif