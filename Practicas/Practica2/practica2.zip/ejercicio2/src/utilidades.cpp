/**
 *  @file utilidades.cpp
 *  @brief Declaracion de funciones necesarias para ejercicio1
 *	Practica 2.
 **/
 
#include <iostream>
#include "utilidades.h"
#include "valor.h"

using namespace std;

/**
 * @brief Funcion para mostrar contenido de Array por pantalla.
 * @param arg array a imprimir
 * @param length tamaño del array arg
 */

int combinaSuma(Valor array1[], int tam1, Valor array2[], int tam2, Valor &resultado[]);



/**
 * @brief Funcion para mezclar dos arrays
 * @param v1 primer array
 * @param length1 tamaño array1
 * @param v2 segundo array
 * @param length2 tamaño segundo array
 * @param resultado array donde se guarda el resultado
 * @return el tamaño del array @a resultado
 */
//Metodo auxiliar para comprobar si un array esta o no.
bool estaContenido(Valor array1[], int tam1, Valor array2[], int tam2);
