//Archivo utilidades.h

#ifndef UTILIDADES_H
#define UTILIDADES_H


void descomponer(int numero, int *factores, int &numeroFactores);
void mostrar(int factores[], int numeroFactores);


#endif