//Archivo utilidades.h

#ifndef UTILIDADES_H
#define UTILIDADES_H


void imprimirArray(int arg[], int length);
void obtenerMayorSecuenciaMonotonaCreciente(int array1[], int utilArray,  int secuenciaCreciente[], int & utilSecuenciaCreciente);
int mayorElemento(int array1[], int utilArray);

#endif