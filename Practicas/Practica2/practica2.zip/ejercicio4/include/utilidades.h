//Archivo utilidades.h

#ifndef UTILIDADES_H
#define UTILIDADES_H

int tamanoCadena(char cadena[]);
int localizarSubcadena(char cadena[], char subcadena3[]);

#endif