#ifndef _UTILIDADES_H__
#define _UTILIDADES_H__

#include <iostream>
using namespace std;

void imprimirArray(double const *secuencia, int util);
int mezclarUnico(double const *array1, int util1, double const *array2, int util2, double *array3);

#endif
