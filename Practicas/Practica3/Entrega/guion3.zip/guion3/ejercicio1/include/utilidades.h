//Archivo utilidades.h

#ifndef UTILIDADES_H
#define UTILIDADES_H

void imprimir(int *secuencia, int util);
void imprimir(int **parray, int util);
void ordenarPunteros(int *array, int **parray, int util);

#endif